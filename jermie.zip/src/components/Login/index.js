// import React, {Component} from 'react';
// import {View, Text} from 'react-native';
// var {FBLogin, FBLoginManager} = require('react-native-facebook-login');
//
// FBLoginManager.setLoginBehavior(FBLoginManager.LoginBehaviors.Web); // defaults to Native
//
// FBLoginManager.loginWithPermissions(["email","user_friends"], function(error, data){
//   if (!error) {
//     console.log("Login data: ", data);
//   } else {
//     console.log("Error: ", error);
//   }
// })
//
// class Login extends Component{
//   render() {
//     return (
//       <View>
//         <Text>
//         </Text>
//         <FBLogin />
//       </View>
//     );
//   }
// }
//
// export default Login;
